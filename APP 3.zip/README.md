# App 3 scaffold — Interrupts & bottom-half

Scaffold level: **~70% complete**.

## What's given

- Complete `IRAM_ATTR` ISR with debounce, scope pulse on GPIO 19
- Two bottom-half paths: binary semaphore AND direct task notification
- Live latency measurement (µs) printed on every press
- Wokwi diagram with button + indicator LED
- An **optional background load** (App 2's four tasks) behind one `#define`, so "measure latency under load" is a flag flip rather than a copy-paste

## Run modes (`WITH_LOAD`)

App 3 reports the same per-press latency fields in both modes; only the contention on Core 1 changes. The switch is one line at the top of `main.c`:

```c
#define WITH_LOAD 0   /* 0 = idle baseline, 1 = App 2's 4 tasks on Core 1 */
```

- `WITH_LOAD = 0` — **idle**. Only the two bottom-half tasks live on Core 1. This is your baseline `latency-max`.
- `WITH_LOAD = 1` — **loaded**. App 2's four periodic tasks (10/20/50/100 ms) run on Core 1 at the rate-monotonic ladder (15/10/5/2). They are a fixed load fixture — deterministic, peripheral-free compute (xorshift, FIR, CRC-32, forced-worst-case insertion sort) carried over from App 2 so the load is reproducible and Wokwi-safe.

**Priority geometry you must account for:** your bottom-half tasks sit at priority **12**. Load Task A is **15**, so it outranks them; load Tasks B/C/D (10/5/2) do not. Under load, Task A can therefore delay a wake while B/C/D cannot preempt your bottom half. That asymmetry is the result you explain in the analysis.

## What you do

1. **Theme rename** — `YOURTHEME` and customize the log messages
2. **Run >= 50 presses, idle** (`WITH_LOAD 0`). Record `latency-max` for both paths.
3. **Flip to `WITH_LOAD 1`**, rebuild, and run >= 50 presses again. Re-record both paths. Confirm the four load tasks are live (their heartbeat counters climb).
4. **Induce a failure** — pick ONE and document the symptom:
   - Remove `portYIELD_FROM_ISR(higher_woken)` → notification is delivered, but the task doesn't run until the next tick
   - Remove `IRAM_ATTR` → first-press latency on cold cache spikes 10-100x
   - Replace `xSemaphoreGiveFromISR` with `xSemaphoreGive` → undefined behavior; system may crash
5. **Defend in README** (see prompts below)

## Capturing latency with Wokwi's logic analyzer

1. In Wokwi, click the "+" near the chip, add a "Logic Analyzer".
2. Connect channel 0 to GPIO 18 (button), channel 1 to GPIO 19 (ISR pulse).
3. Run, click the button N times.
4. Click the logic-analyzer to download a VCD file.
5. Open in PulseView / sigrok or Wokwi's built-in viewer.
6. Measure: time from button-low edge to GPIO-19 rising edge = total interrupt response time (HW latency + your debounce gate + the ISR prologue).
7. Time from GPIO-19 falling edge to the next `[sem]` or `[notif]` log line = bottom-half wake latency. This is the more interesting number, and it's the one that moves when you flip `WITH_LOAD`.

## Engineering analysis (README, graded)

1. **What's in your ISR? What's NOT?** List every line. Defend each (or remove it).
2. **Binary semaphore vs direct task notification** — quote your measured latency numbers. Which is faster? Why?
3. **Latency under load** — quote idle (`WITH_LOAD 0`) vs loaded (`WITH_LOAD 1`) numbers. By what factor does latency increase? Use the priority geometry above (Task A at 15 outranks your bottom half at 12) to explain *which* load task is responsible for the worst-case increase, and why B/C/D are not.
4. **Induced failure** — name the rule you broke, the predicted symptom, the observed symptom, and how they match (or don't).

## Common pitfalls

- **Calling `printf` inside the ISR.** `printf` takes a UART mutex. Mutex from ISR = undefined behavior. The scaffold puts logging in the BOTTOM-HALF tasks for a reason.
- **Forgetting `IRAM_ATTR`.** The first interrupt after a long quiescent period has to load the ISR from flash. That's ~10s of µs of cache fill on top of your nominal latency. With `IRAM_ATTR`, the ISR is in always-on internal RAM.
- **Debounce too short.** A clean push-button bounces for 1–10 ms typically. Wokwi's simulated button is clean, but if you wire a real button, drop `DEBOUNCE_US` to something like 10000 µs.
- **Editing the load-task bodies.** Under `WITH_LOAD 1` the four tasks are a fixture, not the assignment. You're timing your ISR path, so leave their bodies alone; tune only the `*_ITERS`/`*_N`/`*_LEN` knobs if you want a heavier or lighter load.
- **Both bottom-half tasks racing on `latency_max_*`.** This is fine for the scaffold (32-bit reads are atomic, and the max-update is benign-racy). In production you'd use atomics or a mutex — that's App 6's lesson.

## Setup in Wokwi

Same shape as App 1. In a fresh Wokwi ESP-IDF project (`https://wokwi.com/projects/new/esp32-s3`):

1. Replace `diagram.json`, `wokwi.toml`, and `main/CMakeLists.txt` with this folder's versions. (App 3 has no `sdkconfig.defaults` &mdash; uses IDF defaults.)
2. Place this folder's `main.c` at `main/main.c` (delete Wokwi's `main/src/`), **or** leave `main/src/main.c` and edit `main/CMakeLists.txt` to use `SRCS "src/main.c"` + `INCLUDE_DIRS "src"`.
3. Confirm `wokwi.toml`'s `firmware` / `elf` paths match `app3_interrupts` (the `project(...)` name in `CMakeLists.txt`).
4. Click &#9654;.

**No web page in App 3.** All output is on the serial monitor; visual feedback is the yellow ISR-pulse LED on GPIO 19. Turning on the background load (`WITH_LOAD 1`) needs no extra components and no Wi-Fi &mdash; the four tasks are pure compute on Core 1. The Wokwi logic-analyzer instructions above are how you capture the timing numbers.

### Build locally with ESP-IDF instead

```bash
. $HOME/esp/esp-idf/export.sh
idf.py set-target esp32s3
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

To build the loaded configuration from the command line without editing the file, override the flag at configure time:

```bash
idf.py build -DWITH_LOAD=1     # or set it in main.c
```

## Honor code

AI to explain ESP-IDF GPIO ISR mechanics &mdash; fine, cite. AI to write the analysis for you &mdash; no. The latency numbers are yours; the interpretation is yours.

##ISR

IRAM_ATTR uses the rule that it has to be executable without flash and the IRAM_ATTR tells the compiler where to place the function in instruction RAM instead of flash memory
esp_timer_get_time() uses the rule that it has to be fast, non blocking read which uses debounce gates edges within a 200us window without blocking or sleeping so that the button generates with no bounce
gpio_set_level(ISR_PULSE_GPIO,1/o) uses the GPIO register write ISR safe rule and this shows by direct hardware register access with no locks or memeory allocation and used GPIO 19 scope pulse
isr_entry_time_us = now uses the write to volatile shared variable so that it tells the compiler that variables can change unexpected from and ISR which prevents the compiler from caching the value in the register
presses_observer++ uses the writes to volatile counter rule which ensures the task always sees the updated press cound that writted by the ISR
xSemaphoreGiveFromISR uses the ISR-sage signaling primitive uses the block and safely notifies the scheduler that a higher priority task might be ready to run
vTaskNotifyGiveFromISR uses the ISR safe signaling primitive uses the safe variant of the direct task notification API for the half task for latency comparison
portYIELD_FROM_ISR(higher_woken) which uses the trigger immediate context switch rule that removes the signaled task to not run after the interrupt instead of waiting until the scheduler switched tasks on the ticks.


##Latency measurement table

Idle notification max: 30us
Idle sem max: 2594us
Loaded notification max: 2747us
Loaded sem max: 2809us

My final design uses the direct task notification because the idle notification was 30us so its 86 times faster than the semaphore's 2594us and the under load notofication was 2747us and the semaphore was 2809us but the notification got worse than the semaphore.
![Logic Analyzer Waveform](logic-analyzer.png)

##Worst case latency under load

Path.               Idle max.        loaded max.          factor
notification        30us              2747us               -92x
semophore           2594us            2809us               -1.1x
Load task A is a 15 while my bottom half is a 12 so it can delay my wake 

##Induced failure
portYIELD_FROM_ISR(higher_woken) was the thing that was commented out, it makes it so that it requests a context switch on ISR exit if a higher priority task was woken during the ISR. Iwthout it the ISR returns to normal and the schedular does not preempt the current running task for the woken bottom half tasks and wait until the next tick. It runs immediately after the ISR exits instead they would wait until the next tick

##concurrency diagram

INTERRUPT SOURCE
┌─────────────────┐
│   GPIO 18       │  (button, active-low, negedge)
│   Button input  │
└────────┬────────┘
         │ INTR (hardware interrupt)
         ▼
┌─────────────────────────────────────────────────────────────────────┐
│  ESP32-S3  Core 1                                                   │
│                                                                     │
│  ┌──────────────────────────────────────────────┐                  │
│  │  button_isr()   [INTERRUPT CONTEXT]          │──► GPIO 19 pulse │
│  │  IRAM_ATTR · not a task · runs preemptively  │    (scope/LA)    │
│  └───────────────┬──────────────────┬───────────┘                  │
│                  │                  │                               │
│  xSemaphore      │                  │  vTaskNotifyGive              │
│  GiveFromISR()   │                  │  FromISR()                   │
│                  │                  │                               │
│         portYIELD_FROM_ISR(higher_woken)                            │
│                  │                  │                               │
│                  ▼                  ▼                               │
│  ┌───────────────────┐  ┌───────────────────┐                      │
│  │  btn_task_sem     │  │  btn_task_notif   │                      │
│  │  priority 12      │  │  priority 12      │                      │
│  │  semaphore path   │  │  notification     │                      │
│  │  idle max: 2594us │  │  path             │                      │
│  └───────────────────┘  │  idle max: 30us   │                      │
│                         └───────────────────┘                      │


Priority order (high → low):
  attitude_sample (15) > btn_task_sem/notif (12) > control_loop (10)
  > telemetry (5) > health_check (2)

##AI use
Used AI to create concurrent diagram from notes written